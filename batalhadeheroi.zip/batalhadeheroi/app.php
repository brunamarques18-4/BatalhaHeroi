<?php
require_once 'autoload.php';

use App\Model\Heroi;
use App\Model\Arma;
use App\Model\Monstro;
use App\Model\Batalha;

$heroi = new Heroi("Kal'el", 5);
$heroi->adicionarArma(new Arma("gladius", 20, "Fogo"));
$heroi->adicionarArma(new Arma("katana", 15, "Gelo"));

$monstro = new Monstro("Draugr", 50, "Terra");

$batalha = new Batalha($heroi, $monstro);
$resultado = $batalha->iniciar();

echo "==========================\n";
echo "🏆 Vencedor: {$resultado->vencedor}\n";
echo "==========================\n\n";
echo "📜 Log da batalha:\n";
foreach ($resultado->log as $linha) {
    echo "- $linha\n";
}
