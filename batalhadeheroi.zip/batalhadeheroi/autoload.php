<?php

spl_autoload_register(function ($class) {
    $base_dir = __DIR__ . '/app/';
    $class = str_replace('App\\', '', $class);
    $class = str_replace('\\', '/', $class);
    $file = $base_dir . $class . '.php';

    if (file_exists($file)) {
        require_once $file;
    }
});