<?php
namespace App\Model;

class Monstro {
    public string $nome;
    public int $vida;
    public string $tipo;

    public function __construct(string $nome, int $vida, string $tipo) {
        $this->nome = $nome;
        $this->vida = $vida;
        $this->tipo = $tipo;
    }

    public function receberDano(int $dano): void {
        $this->vida -= $dano;
    }

    public function estaVivo(): bool {
        return $this->vida > 0;
    }
}
