<?php
namespace App\Model;

class Batalha {
    public Heroi $heroi;
    public Monstro $monstro;
    public Resultado $resultado;
    public int $turno = 0;

    public function __construct(Heroi $heroi, Monstro $monstro) {
        $this->heroi = $heroi;
        $this->monstro = $monstro;
        $this->resultado = new Resultado();
    }

    public function iniciar(): Resultado {
        $this->resultado->adicionarLog("A batalha começou entre {$this->heroi->nome} e {$this->monstro->nome}");

        while ($this->heroi->estaVivo() && $this->monstro->estaVivo()) {
            $this->turno++;
            $this->resultado->adicionarLog("Turno {$this->turno}");

            if (rand(0, 1) === 0) {
                $this->heroiAtaca();
            } else {
                $this->monstroAtaca();
            }

            $this->resultado->adicionarLog("Vida do herói: {$this->heroi->vida}, Vida do monstro: {$this->monstro->vida}");
        }

        if (!$this->heroi->estaVivo() && !$this->monstro->estaVivo()) {
            $this->resultado->vencedor = "Empate";
            $this->resultado->adicionarLog("Ambos caíram juntos! Empate.");
        } elseif ($this->heroi->estaVivo()) {
            $this->resultado->vencedor = $this->heroi->nome;
            $this->resultado->adicionarLog("O herói {$this->heroi->nome} venceu!");
        } else {
            $this->resultado->vencedor = $this->monstro->nome;
            $this->resultado->adicionarLog("O monstro {$this->monstro->nome} venceu!");
        }

        return $this->resultado;
    }

    private function heroiAtaca(): void {
        $arma = $this->heroi->escolherArma();
        if ($arma) {
            $this->monstro->receberDano($arma->dano);
            $this->resultado->adicionarLog("{$this->heroi->nome} atacou com {$arma->nome} causando {$arma->dano} de dano.");
        }
    }

    private function monstroAtaca(): void {
        $dano = rand(10, 20);
        $this->heroi->receberDano($dano);
        $this->resultado->adicionarLog("{$this->monstro->nome} atacou causando {$dano} de dano no herói.");
    }
}